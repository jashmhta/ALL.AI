import streamlit as st
import asyncio
import uuid
import json
import os
import base64
from datetime import datetime
import sys
import time

# Add the parent directory to the path to import backend modules
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# Import the MultiAIApp class
from backend.main import MultiAIApp

# Set page configuration
st.set_page_config(
    page_title="ALL.AI - Multi-AI Chat Interface",
    page_icon="🤖",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS for GenSpark style with black and grey theme
st.markdown("""
<style>
    /* Main theme colors and styling */
    :root {
        --background-color: #121212;
        --surface-color: #1E1E1E;
        --card-color: #252525;
        --text-color: #FFFFFF;
        --secondary-text-color: #AAAAAA;
        --accent-color: #00A3FF;
        --border-radius: 12px;
        --message-border-radius: 18px;
        --card-shadow: 0 2px 6px rgba(0, 0, 0, 0.3);
    }
    
    /* General styling */
    .stApp {
        background-color: var(--background-color);
        color: var(--text-color);
    }
    
    /* Hide Streamlit elements */
    #MainMenu, footer, header {
        visibility: hidden;
    }
    
    /* Streamlit component overrides */
    .stTextInput > div > div > input {
        background-color: var(--surface-color);
        color: var(--text-color);
        border-radius: var(--border-radius);
        border: 1px solid #333;
        padding: 12px;
    }
    
    .stTextArea > div > div > textarea {
        background-color: var(--surface-color);
        color: var(--text-color);
        border-radius: var(--border-radius);
        border: 1px solid #333;
        padding: 12px;
        font-size: 16px;
        min-height: 120px;
    }
    
    .stButton > button {
        background-color: var(--accent-color);
        color: var(--text-color);
        border-radius: var(--border-radius);
        border: none;
        padding: 10px 20px;
        font-weight: 500;
        transition: all 0.3s ease;
    }
    
    .stButton > button:hover {
        background-color: #0088cc;
        transform: translateY(-2px);
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
    }
    
    /* Header styling */
    .main-header {
        text-align: center;
        padding: 1.5rem;
        margin-bottom: 1.5rem;
        background-color: var(--surface-color);
        border-radius: var(--border-radius);
        box-shadow: var(--card-shadow);
    }
    
    .main-header h1 {
        margin: 0;
        color: var(--text-color);
        font-size: 1.8rem;
        font-weight: 600;
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 10px;
    }
    
    .main-header h1 img {
        width: 32px;
        height: 32px;
    }
    
    /* Chat container styling */
    .chat-container {
        display: flex;
        flex-direction: column;
        gap: 20px;
        padding: 20px;
        max-height: 600px;
        overflow-y: auto;
        background-color: var(--surface-color);
        border-radius: var(--border-radius);
        box-shadow: var(--card-shadow);
        margin-bottom: 20px;
    }
    
    /* Message styling - GenSpark style */
    .message-row {
        display: flex;
        width: 100%;
        margin-bottom: 16px;
    }
    
    .message-row.user {
        justify-content: flex-end;
    }
    
    .message-row.assistant {
        justify-content: flex-start;
    }
    
    .message {
        max-width: 80%;
        padding: 16px;
        border-radius: var(--message-border-radius);
        position: relative;
        box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        animation: fadeIn 0.3s ease-in-out;
    }
    
    @keyframes fadeIn {
        from { opacity: 0; transform: translateY(10px); }
        to { opacity: 1; transform: translateY(0); }
    }
    
    .user-message {
        background-color: #2A2A2A;
        color: var(--text-color);
        border-radius: var(--message-border-radius);
        margin-left: auto;
        border-bottom-right-radius: 4px;
    }
    
    .assistant-message {
        background-color: var(--card-color);
        color: var(--text-color);
        border-radius: var(--message-border-radius);
        border-bottom-left-radius: 4px;
    }
    
    .message-content {
        white-space: pre-wrap;
        line-height: 1.6;
        font-size: 15px;
    }
    
    /* Copy button */
    .copy-button {
        display: inline-block;
        padding: 4px 10px;
        background-color: rgba(0, 0, 0, 0.2);
        color: var(--secondary-text-color);
        border-radius: 4px;
        font-size: 12px;
        margin-top: 10px;
        cursor: pointer;
        transition: all 0.2s ease;
    }
    
    .copy-button:hover {
        background-color: rgba(0, 0, 0, 0.4);
        color: var(--text-color);
    }
    
    /* Mixture of Agents section */
    .mixture-header {
        font-size: 18px;
        font-weight: bold;
        margin-top: 28px;
        margin-bottom: 16px;
        color: var(--text-color);
        padding-bottom: 8px;
        border-bottom: 1px solid rgba(255, 255, 255, 0.1);
    }
    
    .model-card {
        background-color: var(--card-color);
        border-radius: var(--border-radius);
        padding: 16px;
        margin-bottom: 16px;
        position: relative;
        box-shadow: var(--card-shadow);
        border-left: 4px solid transparent;
        transition: all 0.2s ease;
    }
    
    .model-card:hover {
        transform: translateY(-2px);
        box-shadow: 0 6px 12px rgba(0, 0, 0, 0.2);
    }
    
    .model-card.gpt {
        border-left-color: #10A37F;
    }
    
    .model-card.claude {
        border-left-color: #9C5FFF;
    }
    
    .model-card.gemini {
        border-left-color: #4285F4;
    }
    
    .model-card.llama {
        border-left-color: #00E8FC;
    }
    
    .model-card.openrouter {
        border-left-color: #FF6B6B;
    }
    
    .model-header {
        display: flex;
        align-items: center;
        gap: 10px;
        margin-bottom: 12px;
    }
    
    .model-icon {
        width: 24px;
        height: 24px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 14px;
        background-color: #333;
        color: white;
        font-weight: bold;
    }
    
    .model-icon.gpt {
        background-color: #10A37F;
    }
    
    .model-icon.claude {
        background-color: #9C5FFF;
    }
    
    .model-icon.gemini {
        background-color: #4285F4;
    }
    
    .model-icon.llama {
        background-color: #00E8FC;
        color: #000;
    }
    
    .model-icon.openrouter {
        background-color: #FF6B6B;
    }
    
    .model-name {
        font-weight: bold;
        font-size: 16px;
    }
    
    .model-content {
        font-size: 15px;
        line-height: 1.6;
        white-space: pre-wrap;
    }
    
    .model-indicator {
        position: absolute;
        top: 16px;
        left: -8px;
        width: 12px;
        height: 12px;
        border-radius: 50%;
        background-color: #00A3FF;
    }
    
    .dismiss-button {
        position: absolute;
        top: 12px;
        right: 12px;
        width: 24px;
        height: 24px;
        border-radius: 50%;
        background-color: rgba(255, 255, 255, 0.1);
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 14px;
        cursor: pointer;
        transition: all 0.2s ease;
    }
    
    .dismiss-button:hover {
        background-color: rgba(255, 255, 255, 0.2);
    }
    
    /* Input area styling */
    .input-area {
        display: flex;
        align-items: center;
        background-color: var(--surface-color);
        border-radius: var(--border-radius);
        padding: 12px;
        margin-top: 20px;
        border: 1px solid #333;
        box-shadow: var(--card-shadow);
        transition: all 0.3s ease;
    }
    
    .input-area:focus-within {
        border-color: var(--accent-color);
        box-shadow: 0 0 0 2px rgba(0, 163, 255, 0.2);
    }
    
    .input-box {
        flex-grow: 1;
        background-color: transparent;
        border: none;
        color: var(--text-color);
        padding: 10px;
        outline: none;
        font-size: 16px;
        resize: none;
        min-height: 60px;
    }
    
    .send-button {
        background-color: var(--accent-color);
        border: none;
        color: var(--text-color);
        cursor: pointer;
        padding: 10px 16px;
        border-radius: 8px;
        font-weight: 500;
        transition: all 0.2s ease;
        display: flex;
        align-items: center;
        gap: 6px;
    }
    
    .send-button:hover {
        background-color: #0088cc;
        transform: translateY(-2px);
    }
    
    .send-button svg {
        width: 16px;
        height: 16px;
    }
    
    /* Thinking indicator */
    .thinking-indicator {
        display: flex;
        align-items: center;
        gap: 6px;
        margin: 12px 0;
        color: var(--secondary-text-color);
        font-size: 15px;
        animation: fadeIn 0.5s ease;
    }
    
    .thinking-dot {
        width: 8px;
        height: 8px;
        background-color: var(--secondary-text-color);
        border-radius: 50%;
        animation: pulse 1.5s infinite;
    }
    
    .thinking-dot:nth-child(2) {
        animation-delay: 0.2s;
    }
    
    .thinking-dot:nth-child(3) {
        animation-delay: 0.4s;
    }
    
    @keyframes pulse {
        0% { opacity: 0.3; transform: scale(0.8); }
        50% { opacity: 1; transform: scale(1.2); }
        100% { opacity: 0.3; transform: scale(0.8); }
    }
    
    /* Model selector */
    .model-selector {
        background-color: var(--surface-color);
        border-radius: var(--border-radius);
        padding: 16px;
        margin-bottom: 20px;
        box-shadow: var(--card-shadow);
    }
    
    .model-option {
        display: flex;
        align-items: center;
        gap: 10px;
        padding: 10px;
        cursor: pointer;
        border-radius: 8px;
        transition: all 0.2s ease;
    }
    
    .model-option:hover {
        background-color: rgba(255, 255, 255, 0.05);
    }
    
    .model-radio {
        width: 18px;
        height: 18px;
        border-radius: 50%;
        border: 2px solid #555;
        display: flex;
        align-items: center;
        justify-content: center;
        transition: all 0.2s ease;
    }
    
    .model-radio.selected {
        border-color: var(--accent-color);
    }
    
    .model-radio.selected::after {
        content: "";
        width: 10px;
        height: 10px;
        border-radius: 50%;
        background-color: var(--accent-color);
        animation: scaleIn 0.2s ease;
    }
    
    @keyframes scaleIn {
        from { transform: scale(0); }
        to { transform: scale(1); }
    }
    
    /* Code blocks */
    pre {
        background-color: #1A1A1A;
        border-radius: 8px;
        padding: 16px;
        overflow-x: auto;
        margin: 12px 0;
        border: 1px solid #333;
    }
    
    code {
        font-family: 'JetBrains Mono', 'Courier New', monospace;
        font-size: 14px;
        line-height: 1.5;
    }
    
    .keyword {
        color: #CF99FF;
    }
    
    .function {
        color: #61AFEF;
    }
    
    .string {
        color: #98C379;
    }
    
    .comment {
        color: #7F848E;
    }
    
    .number {
        color: #D19A66;
    }
    
    /* Empty state */
    .empty-state {
        text-align: center;
        padding: 4rem 2rem;
        color: var(--secondary-text-color);
        background-color: var(--surface-color);
        border-radius: var(--border-radius);
        box-shadow: var(--card-shadow);
    }
    
    .empty-state h3 {
        font-size: 1.8rem;
        margin-bottom: 1rem;
        color: var(--text-color);
    }
    
    .empty-state p {
        font-size: 1.1rem;
        max-width: 600px;
        margin: 0 auto;
    }
    
    /* Sidebar styling */
    .sidebar .stButton button {
        width: 100%;
        margin-bottom: 12px;
    }
    
    /* File upload styling */
    .uploadedFile {
        background-color: var(--card-color);
        border-radius: 8px;
        padding: 12px;
        margin-top: 8px;
        display: flex;
        align-items: center;
        gap: 8px;
    }
    
    .uploadedFile .icon {
        color: var(--accent-color);
    }
    
    .uploadedFile .info {
        flex-grow: 1;
    }
    
    .uploadedFile .name {
        font-weight: 500;
    }
    
    .uploadedFile .size {
        font-size: 12px;
        color: var(--secondary-text-color);
    }
    
    .uploadedFile .remove {
        color: #FF5555;
        cursor: pointer;
    }
    
    /* Mobile responsiveness */
    @media (max-width: 768px) {
        .message {
            max-width: 90%;
        }
        
        .main-header h1 {
            font-size: 1.5rem;
        }
        
        .model-card {
            padding: 12px;
        }
    }
    
    /* Animations */
    @keyframes slideInRight {
        from { transform: translateX(20px); opacity: 0; }
        to { transform: translateX(0); opacity: 1; }
    }
    
    @keyframes slideInLeft {
        from { transform: translateX(-20px); opacity: 0; }
        to { transform: translateX(0); opacity: 1; }
    }
    
    .message-row.user .message {
        animation: slideInRight 0.3s ease-out;
    }
    
    .message-row.assistant .message {
        animation: slideInLeft 0.3s ease-out;
    }
    
    /* Memory display styling */
    .memory-container {
        background-color: var(--card-color);
        border-radius: var(--border-radius);
        padding: 16px;
        margin-bottom: 20px;
        box-shadow: var(--card-shadow);
    }
    
    .memory-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 12px;
        padding-bottom: 8px;
        border-bottom: 1px solid rgba(255, 255, 255, 0.1);
    }
    
    .memory-title {
        font-weight: bold;
        font-size: 16px;
        color: var(--text-color);
    }
    
    .memory-controls {
        display: flex;
        gap: 8px;
    }
    
    .memory-control {
        background-color: rgba(255, 255, 255, 0.1);
        border: none;
        color: var(--secondary-text-color);
        width: 24px;
        height: 24px;
        border-radius: 4px;
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        transition: all 0.2s ease;
    }
    
    .memory-control:hover {
        background-color: rgba(255, 255, 255, 0.2);
        color: var(--text-color);
    }
    
    .memory-item {
        padding: 8px;
        border-radius: 4px;
        margin-bottom: 8px;
        background-color: rgba(255, 255, 255, 0.05);
        font-size: 14px;
        line-height: 1.4;
        position: relative;
        overflow: hidden;
        transition: all 0.2s ease;
    }
    
    .memory-item:hover {
        background-color: rgba(255, 255, 255, 0.1);
    }
    
    .memory-item.user {
        border-left: 2px solid #10A37F;
    }
    
    .memory-item.assistant {
        border-left: 2px solid #9C5FFF;
    }
    
    .memory-item-content {
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
    }
    
    .memory-item-expanded .memory-item-content {
        white-space: normal;
    }
    
    .memory-item-toggle {
        position: absolute;
        right: 8px;
        top: 8px;
        background: none;
        border: none;
        color: var(--secondary-text-color);
        cursor: pointer;
        font-size: 12px;
    }
    
    .memory-item-toggle:hover {
        color: var(--text-color);
    }
    
    .memory-empty {
        text-align: center;
        padding: 16px;
        color: var(--seco
(Content truncated due to size limit. Use line ranges to read in chunks)