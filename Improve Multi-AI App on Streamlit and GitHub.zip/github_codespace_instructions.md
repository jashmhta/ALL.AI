# GitHub Codespace Deployment Instructions

This guide will help you deploy the Multi-AI application to Render using your GitHub Codespace.

## Prerequisites

- Access to your GitHub Codespace for the ALL.AI repository
- The Render API key (already included in the deployment script)
- API keys for the AI services you want to use

## Deployment Steps

1. **Open your GitHub Codespace**
   - Go to https://github.com/jashmhta/ALL.AI
   - Click on the "Code" button
   - Select the "Codespaces" tab
   - Click on "Create codespace on master" or use an existing codespace

2. **Set up environment variables**
   - In your codespace terminal, set the API keys as environment variables:
   ```bash
   export OPENAI_API_KEY="your_openai_api_key_here"
   export GEMINI_API_KEY="your_gemini_api_key_here"
   export HUGGINGFACE_API_KEY="your_huggingface_api_key_here"
   export OPENROUTER_API_KEY="your_openrouter_api_key_here"
   export CLAUDE_API_KEY="your_claude_api_key_here"
   export LLAMA_API_KEY="your_llama_api_key_here"
   export BOTPRESS_API_KEY="your_botpress_api_key_here"
   ```

3. **Pull the latest changes**
   - Make sure your codespace has the latest code:
   ```bash
   git pull origin master
   ```

4. **Make the deployment script executable**
   ```bash
   chmod +x deployment/render_deploy.sh
   ```

5. **Run the deployment script**
   ```bash
   ./deployment/render_deploy.sh
   ```

6. **Monitor the deployment**
   - The script will output a URL where you can monitor the deployment status
   - Once deployed, your application will be available at: https://multi-ai-app.onrender.com

## Troubleshooting

If you encounter any issues during deployment:

1. **Check the Render logs**
   - Go to the Render dashboard
   - Select your "multi-ai-app" service
   - Click on "Logs" to see what might be causing the issue

2. **Verify API keys**
   - Ensure all API keys are correctly set as environment variables
   - Check that the Render API key in the script is valid

3. **Manual deployment**
   If the script doesn't work, you can deploy manually:
   - Go to https://dashboard.render.com/
   - Click "New" and select "Web Service"
   - Connect your GitHub repository
   - Configure with the following settings:
     - Build Command: `pip install -r requirements.txt`
     - Start Command: `streamlit run frontend/app.py --server.port=$PORT --server.address=0.0.0.0`
   - Add all your API keys as environment variables
   - Click "Create Web Service"

## Post-Deployment

After successful deployment:

1. **Test all AI models**
   - Visit your deployed application
   - Try each AI model individually to ensure they're working
   - Test the synthesis functionality with multiple models

2. **Set up a custom domain (optional)**
   - In the Render dashboard, go to your service settings
   - Click on "Custom Domain"
   - Follow the instructions to add your domain

3. **Monitor usage**
   - Keep an eye on your API usage to avoid unexpected charges
   - Consider setting up usage alerts in your AI service dashboards
